# Gün Projesi: CSS Rules Kapadokya

Kapadokyayı çok seviyorsun. Sosyal medyada dolaşırken bir site ile karşılaştın. Tasarımı çok da zor değil gibi geldi. Şu ana kadar öğrendiklerini pratik etmek için bu sitenin aynısını yapmaya karar verdin.

\`design\` klasörü içinde gördüğün siteden aldığın screenshot('screenshot.png') dosyası var. Hedef bunun aynısını index.html ve index.css dosyasında belirtilen yönergelere uyarak yapmak.

Kullanılacak resim dosyaları \`assets\` klasörü içinde.
