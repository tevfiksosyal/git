module.exports = {
  verbose: false,
  watchPathIgnorePatterns: ['./resultz.json'],
  moduleFileExtensions: ['js', 'html', 'css'],
};
